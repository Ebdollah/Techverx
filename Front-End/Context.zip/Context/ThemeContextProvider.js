// Todo: Create & manage context in this file
import React from 'react';
export const MyContext = React.createContext();

export default function ThemeContextProvider({ children }) {
    
  const [theme, setTheme] = React.useState('light');
  return(
      <MyContext.Provider value={{theme, setTheme}}>
      {children}
      </MyContext.Provider>
      )
  // Todo: Add the component code (incl. dynamic context value)
}
